
<?php $__env->startSection('judul','Transaksi'); ?>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
"use strict";
// const nama = <?php echo e(json_encode($produk_js)); ?>

let namas = <?php echo json_encode($produk_js, 15, 512) ?>;
let json = JSON.parse(namas);


$(document).ready(function domReady() {
  
  $('.js-example-basic-single').select2();
});



$('#nama').change(function() { 
  $('#jual').val(39000);
  const rupiah = (number)=>{
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR"
    }).format(number);
  }

  json.forEach(element => {
    if (element.id == $('#nama').val()) {
      $('#jual').val(rupiah(element.jual));
    }
  });
});

</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
      <div class="col-12">
        <div class="card my-4">
          <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
            <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                <a href="<?php echo e(route('transaksi_proses')); ?>" class="btn bg-gradient-secondary" style="float: right; margin-right: 10px; margin-top: -5px;"><i class="fa-solid fa-plus"></i> Data</a>
              <h6 class="text-white text-capitalize ps-3" >Transaksi</h6>
            </div>
          </div>
        
          <div class="card-body px-0 pb-2">
            <div class="table-responsive p-0">
              <table class="table align-items-center mb-0 table-flush display" id="datatable-basic">
                <thead>
                  <tr>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7">No</th>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7">Nama</th>
                    <th class=" text-uppercase text-secondary text-xs font-weight-bolder opacity-7">Harga</th>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-2">Lunas</th>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-2">Pembayaran</th>
                    <th class="text-uppercase text-secondary  text-center  text-xs font-weight-bolder opacity-7 ps-2">Keterangan</th>
                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                        $no=1;
                    ?>
                   <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                 
                        <tr>
                        <td>
                            <div class="d-flex font-weight-bold ">
                                <?php echo e($no++); ?>

                            </div>
                        </td>
                          <td>
                              <div class="d-flex font-weight-bold ">
                                <?php echo e($item->nama_produk); ?>

                              </div>
                          </td>
                          <td>
                            <p class=" font-weight-bold mb-0"><?php echo e("Rp " . number_format($item->jual,0,',','.')); ?></p>
                          </td>
                          <td>
                            <div class="d-flex font-weight-bold ">
                                <?php if($item->status == "gangguan"): ?>
                                <span class="badge badge-sm bg-gradient-danger">Belum Bayar</span>
                                <?php else: ?>
                                <span class="badge badge-sm bg-gradient-success">Lunas</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <div class="d-flex font-weight-bold ">
                              <?php echo e($item->payment->nama); ?>

                            </div>
                        </td>
                        <td>
                            <div class="d-flex font-weight-bold ">
                              <?php echo e($item->keterangan); ?>

                            </div>
                        </td>
                         
                            
                            <td class="align-middle   ">
                              <div class="text-center">
                              
                              <a href="<?php echo e(route('produk_delete', ['id'=>$item->id])); ?>" onclick="if (confirm('Delete selected item?')){return true;}else{event.stopPropagation(); event.preventDefault();};" title="Link Title" style="margin: 10px;"><i class="fa-solid fa-trash"></i></a>
                              </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a href="<?php echo e(redirect()->back()->getTargetUrl()); ?>" class="btn btn-secondary" >
      << Kembali
    </a>

  </div>

  
  <!-- Modal -->
  <div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title font-weight-normal" id="tambahDataLabel">Tambah Transaksi</h5>
          <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form method="post" action="<?php echo e(route('produk_simpan')); ?>">
          <?php echo csrf_field(); ?>
        <div class="modal-body">
           
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group input-group-static mb-4">
                      <label for="exampleFormControlSelect1" class="ms-0">Nama</label>
                      <select class="js-example-basic-single" id="nama" name="kode_produk" class="js-example-basic-single" name="state" required>
                        
                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->label->jenis->kategori->nama." ".$item->label->jenis->nama." ".$item->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                    <hr>
                  <div class="col-md-12">
                    <div class="form-group input-group-outline">
                      <label class="form-label">Harga</label>
                      <input type="text" name="jual" id="jual" class="form-control" disabled>
                    </div>
                  </div>
                </div>
                <div class="col-md-12" style="margin-top: 10px;">
                  <div class="form-group input-group-static mb-4">
                    <label for="exampleFormControlSelect1" class="ms-0">Metode</label>
                    <select class="form-control" name="lunas">
                      <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item_p->id); ?>"><?php echo e($item_p->nama); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group input-group-static mb-4">
                    <label for="exampleFormControlSelect1" class="ms-0">Keterangan</label>
                    <select class="form-control" name="lunas">
                      <option value="keluar" selected>Keluar</option>
                      <option value="Masuk">Masuk</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group input-group-static mb-4">
                    <label for="exampleFormControlSelect1" class="ms-0">Pembayaran</label>
                    <select class="form-control" name="lunas">
                      <option value="1" selected>Lunas</option>
                      <option value="0">Hutang</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group input-group-static mb-4">
                    <label for="exampleFormControlSelect1" class="ms-0">Deskripsi</label>
                    <textarea name="deskripsi" id="" cols="30" rows="10"></textarea>
                  </div>
                </div>
             
        </div>
        <div class="modal-footer">
          <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn bg-gradient-primary">Save changes</button>
        </div>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AMD\Documents\project\jrmedia\resources\views/transaksi/transaksi.blade.php ENDPATH**/ ?>