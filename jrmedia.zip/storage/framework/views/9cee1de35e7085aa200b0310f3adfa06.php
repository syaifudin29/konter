
<?php $__env->startSection('judul','Produk'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
      <div class="col-12">
        <div class="card my-4">
          <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
            <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                <button data-bs-toggle="modal" data-bs-target="#tambahData" class="btn bg-gradient-secondary" style="float: right; margin-right: 10px; margin-top: -5px;"><i class="fa-solid fa-plus"></i> Data</button>
              <h6 class="text-white text-capitalize ps-3" >Produk <?php echo e($jns->kategori->nama); ?> <?php echo e($jns->nama); ?></h6>
            </div>
          </div>
          <div class="card-body px-0 pb-2">
            <div class="table-responsive p-0">
              <table class="table align-items-center mb-0 table-flush display" id="datatable-basic">
                <thead>
                  <tr>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7">Nama</th>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-2">Kategori</th>
                    <th class="text-uppercase text-secondary  text-center  text-xs font-weight-bolder opacity-7 ps-2">Status</th>
                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">beli</th>
                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">Jual</th>
                    
                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $__currentLoopData = $lbl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lb->id == $item->label_id): ?>
                        <tr>
                          <td>
                              <div class="d-flex font-weight-bold text-uppercase">
                                <?php echo e($item->label->jenis->kategori->nama." ".$item->nama); ?>

                              </div>
                          </td>
                          <td>
                            <p class=" font-weight-bold mb-0 text-capitalize"><?php echo e($item->label->jenis->nama); ?></p>
                            <p class=" text-secondary mb-0 text-capitalize"><?php echo e($item->label->nama); ?></p>
                          </td>
                          <td class="align-middle text-center text-sm">
                            <?php if($item->status == "gangguan"): ?>
                              <span class="badge badge-sm bg-gradient-danger"><?php echo e($item->status); ?></span>
                            <?php else: ?>
                              <span class="badge badge-sm bg-gradient-success"><?php echo e($item->status); ?></span>
                            <?php endif; ?>
                          </td>
                          
                          <td class="align-middle text-center">
                            <span class=" text-secondary font-weight-bold text text-info"><?php echo e("Rp " . number_format($item->beli,0,',','.')); ?></span>
                          </td>
                          <td class="align-middle text-center">
                              <span class=" text-secondary font-weight-bold text text-success"><?php echo e("Rp " . number_format($item->jual,0,',','.')); ?></span>
                            </td>
                            
                            <td class="align-middle   ">
                              <div class="text-center">
                              <a href="" data-bs-toggle="modal" data-bs-target="#editProduk<?php echo e($item->id); ?>" style="margin: 10px;"><i class="fa-solid fa-pen-to-square"></i></a>
                              |
                              <a href="<?php echo e(route('produk_delete', ['id'=>$item->id])); ?>" onclick="if (confirm('Delete selected item?')){return true;}else{event.stopPropagation(); event.preventDefault();};" title="Link Title" style="margin: 10px;"><i class="fa-solid fa-trash"></i></a>
                              </div>
                            </td>
                        </tr>
                        
                        <!-- Modal -->
                        <div class="modal fade" id="editProduk<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editProdukLabel" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title font-weight-normal" id="editProdukLabel">Edit Produk</h5>
                                <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <form method="post" action="<?php echo e(route('produk_update')); ?>">
                                <?php echo csrf_field(); ?>
                              <div class="modal-body">
                                
                                      <div class="row">
                                        <div class="col-md-12">
                                          <div class="form-group my-3">
                                            <label class="form-label">Nama</label>
                                            <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                            <input type="text" class="form-control" name="nama" value="<?php echo e($item->nama); ?>" placeholder="masukkan nama" required>
                                          </div>
                                        </div>
                                        <div class="col-md-12">
                                          <div class="input-group input-group-static mb-4">
                                            <label for="exampleFormControlSelect1" class="ms-0">Label</label>
                                            <select name="label_id" class="form-control" id="exampleFormControlSelect1" required>
                                              <?php $__currentLoopData = $lbl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lbls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <?php
                                                  if ($lbls->id == $item->label_id) {
                                                    $select = "selected";
                                                  }else{
                                                    $select = "";
                                                  }
                                              ?>
                                            
                                              <option <?php echo e($select); ?> value="<?php echo e($lbls->id); ?>"><?php echo e($lbls->nama); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              
                                            </select>
                                          </div>
                                        </div>
                                        <div class="col-md-12">
                                          <div class="input-group input-group-static mb-4">
                                            <label for="exampleFormControlSelect1" class="ms-0">Status</label>
                                            <select name="status" class="form-control" id="exampleFormControlSelect1" required>
                                              
                                              <option <?php echo e($item->status=='aktif'?'selected':''); ?> selected value="aktif">Aktif</option>
                                              <option <?php echo e($item->status=='gangguan'?'selected':''); ?> value="gangguan">Gangguan</option>
                                            </select>
                                          </div>
                                        </div>
                                        <div class="col-md-12">
                                          <div class="form-group my-3">
                                            <label class="form-label">Harga Beli</label>
                                            <input type="number" value="<?php echo e($item->beli); ?>" name="beli" class="form-control" required>
                                          </div>
                                        </div>
                                        <div class="col-md-12">
                                          <div class="form-group my-3">
                                            <label class="form-label">Harga Jual</label>
                                            <input type="number" value="<?php echo e($item->jual); ?>" name="jual" class="form-control" required>
                                          </div>
                                        </div>
                                        <div class="col-md-12">
                                          <div class="form-group">
                                            <label class="form-label">Keterangan</label>
                                            <textarea  name="keterangan" class="form-control" rows="5" placeholder=" ....." spellcheck="false" ><?php echo e($item->keterangan); ?></textarea>
                                          </div>
                                        </div>
                                      </div>
                                  
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn bg-gradient-primary">Save changes</button>
                              </div>
                            </form>
                            </div>
                          </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a href="<?php echo e(redirect()->back()->getTargetUrl()); ?>" class="btn btn-secondary" >
      << Kembali
    </a>

  </div>

  
  <!-- Modal -->
  <div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title font-weight-normal" id="tambahDataLabel">Input Produk</h5>
          <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form method="post" action="<?php echo e(route('produk_simpan')); ?>">
          <?php echo csrf_field(); ?>
        <div class="modal-body">
           
                <div class="row">
                  <div class="col-md-12">
                    <div class="input-group input-group-outline my-3">
                      <label class="form-label">Nama</label>
                      <input type="text" class="form-control" name="nama" required>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="input-group input-group-static mb-4">
                      <label for="exampleFormControlSelect1" class="ms-0">Label</label>
                      <select name="label_id" class="form-control" id="exampleFormControlSelect1" required>
                        <?php $__currentLoopData = $lbl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lbl->id); ?>"><?php echo e($lbl->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="input-group input-group-static mb-4">
                      <label for="exampleFormControlSelect1" class="ms-0">Status</label>
                      <select name="status" class="form-control" id="exampleFormControlSelect1" required>
                        <option selected value="aktif">Aktif</option>
                        <option value="gangguan">Gangguan</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="input-group input-group-outline my-3">
                      <label class="form-label">Harga Beli</label>
                      <input type="number" name="beli" class="form-control" required>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="input-group input-group-outline my-3">
                      <label class="form-label">Harga Jual</label>
                      <input type="number" name="jual" class="form-control" required>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="form-label">Keterangan</label>
                      <textarea  name="keterangan" class="form-control" rows="5" placeholder=" ....." spellcheck="false"></textarea>
                    </div>
                  </div>
                </div>
             
        </div>
        <div class="modal-footer">
          <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn bg-gradient-primary">Save changes</button>
        </div>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AMD\Documents\project\jrmedia\resources\views/produk/produk.blade.php ENDPATH**/ ?>