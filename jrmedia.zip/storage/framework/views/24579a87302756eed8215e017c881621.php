
<?php $__env->startSection('judul','Alat'); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  const dataTablekategori = new simpleDatatables.DataTable("#datatable-kat", {
    searchable: true,
    fixedHeight: true
  });
  const dataTableJenis = new simpleDatatables.DataTable("#datatable-jenis", {
    searchable: true,
    fixedHeight: true
  });
  const dataTableLabel = new simpleDatatables.DataTable("#datatable-label", {
    searchable: true,
    fixedHeight: true
  });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
      
      <div class="col-md-4">
        <div class="card my-4">
          <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
            <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                <button data-bs-toggle="modal" data-bs-target="#tambahDataKategori" class="btn bg-gradient-secondary" style="float: right; margin-right: 10px; margin-top: -5px;"><i class="fa-solid fa-plus"></i> Data</button>
              <h6 class="text-white text-capitalize ps-3">Kategori</h6>
            </div>
          </div>
          <div class="card-body px-0 pb-2">
            <div class="table-responsive p-0">
              <table class="table align-items-center mb-0 table-flush display" id="datatable-kat">
                <thead>
                  <tr>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7">No</th>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-2">Kategori</th>
                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">Hapus</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                    $no=1;
                    ?>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                        <div class="d-flex px-2 py-1">
                            <?php echo e($no++); ?>

                        </div>
                    </td>
                    <td>
                        <div class="d-flex px-2 py-1 text-capitalize">
                         <?php echo e($item->nama); ?>

                        </div>
                    </td>
                      <td class="align-middle   ">
                        <div class="text-center">
                        <a href="" data-bs-toggle="modal" data-bs-target="#editDataKategori<?php echo e($item->id); ?>" style="margin: 10px;"><i class="fa-solid fa-edit"></i></a>
                        <a href="<?php echo e(route('kategori_delete', ['id'=>$item->id])); ?>" onclick="if (confirm('Delete selected item?')){return true;}else{event.stopPropagation(); event.preventDefault();};" style="margin: 10px;"><i class="fa-solid fa-trash"></i></a>
                        </div>
                      </td>
                  </tr>
                  <!-- Modal edit kategori -->
                  <div class="modal fade" id="editDataKategori<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                      <div class="modal-content">
                        <form method="post" action="<?php echo e(route('kategori_update')); ?>">
                          <?php echo csrf_field(); ?>
                        <div class="modal-header">
                          <h5 class="modal-title font-weight-normal" id="tambahDataLabel">Edit Kategori</h5>
                          <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                                <div class="row">
                                  <div class="col-md-12">        
                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">         
                                    <div class="form-group my-3">
                                      <label class="form-label">Nama</label>
                                      <input name="nama" type="text" class="form-control" value="<?php echo e($item->nama); ?>" required>
                                    </div>
                                  </div>
                                  <div class="col-md-12">
                                    <div class="form-group">
                                      <label class="form-label">Keterangan</label>
                                      <textarea  name="keterangan" class="form-control" rows="5" placeholder="keterangan" spellcheck="false"><?php echo e($item->keterangan); ?></textarea>
                                    </div>
                                  </div>
                                </div> 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
                          <button type="submit" class="btn bg-gradient-primary">Update Kategori</button>
                        </div>
                      </form>
                      </div>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-4">
        <div class="card my-4">
          <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
            <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                <button data-bs-toggle="modal" data-bs-target="#tambahDataJenis" class="btn bg-gradient-secondary" style="float: right; margin-right: 10px; margin-top: -5px;"><i class="fa-solid fa-plus"></i> Data</button>
              <h6 class="text-white text-capitalize ps-3">Jenis</h6>
            </div>
          </div>
          <div class="card-body px-0 pb-2">
            <div class="table-responsive p-0">
              <table class="table align-items-center mb-0 table-flush display" id="datatable-jenis">
                <thead>
                  <tr>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7">No</th>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-2">Jenis</th>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-2">Kategori</th>
                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">Hapus</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                    $no=1;
                    ?>
                    <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                        <div class="d-flex px-2 py-1">
                            <?php echo e($no++); ?>

                        </div>
                    </td>
                    <td>
                        <div class="d-flex px-2 py-1 text-capitalize">
                        <?php echo e($item->nama); ?>

                        </div>
                    </td>
                    <td>
                      <div class="d-flex px-2 py-1">
                        <?php echo e($item->kategori->nama); ?>

                      </div>
                  </td>
                      <td class="align-middle   ">
                        <div class="text-center">
                          <a href="" data-bs-toggle="modal" data-bs-target="#editDataJenis<?php echo e($item->id); ?>" style="margin: 10px;"><i class="fa-solid fa-edit"></i></a>
                          <a href="<?php echo e(route('jenis_delete', ['id'=>$item->id])); ?>" onclick="if (confirm('Delete selected item?')){return true;}else{event.stopPropagation(); event.preventDefault();};" style="margin: 10px;"><i class="fa-solid fa-trash"></i></a>
                        </div>
                      </td>
                  </tr>
                  <!-- Modal edit kategori -->
                  <div class="modal fade" id="editDataJenis<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                      <div class="modal-content">
                        <form method="post" action="<?php echo e(route('jenis_update')); ?>">
                          <?php echo csrf_field(); ?>
                        <div class="modal-header">
                          <h5 class="modal-title font-weight-normal" id="tambahDataLabel">Edit Jenis</h5>
                          <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                                <div class="row">
                                  <div class="col-md-12">        
                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">         
                                    <div class="form-group my-3">
                                      <label class="form-label">Nama</label>
                                      <input name="nama" type="text" class="form-control" value="<?php echo e($item->nama); ?>" required>
                                    </div>
                                  </div>
                                  <div class="col-md-12">
                                    <div class="input-group input-group-static mb-4">
                                      <label for="exampleFormControlSelect1" class="ms-0">Kategori</label>
                                      <select name="kategori_id" class="form-control" id="exampleFormControlSelect1">
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($kat->id == $item->kategori_id): ?>
                                            <?php
                                                $select = "selected";
                                            ?>
                                        <?php else: ?>
                                          <?php
                                            $select = "";
                                          ?>
                                        <?php endif; ?>
                                        <option <?php echo e($select); ?> value="<?php echo e($kat->id); ?>"><?php echo e($kat->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                      </select>
                                    </div>
                                  </div>
                                  <div class="col-md-12">
                                    <div class="form-group">
                                      <label class="form-label">Keterangan</label>
                                      <textarea  name="keterangan" class="form-control" rows="5" placeholder="keterangan" spellcheck="false" ><?php echo e($item->keterangan); ?></textarea>
                                    </div>
                                  </div>
                                </div> 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
                          <button type="submit" class="btn bg-gradient-primary">Update Jenis</button>
                        </div>
                      </form>
                      </div>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-4">
        <div class="card my-4">
          <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
            <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                <button data-bs-toggle="modal" data-bs-target="#tambahDataLabel1" class="btn bg-gradient-secondary" style="float: right; margin-right: 10px; margin-top: -5px;"><i class="fa-solid fa-plus"></i> Data</button>
              <h6 class="text-white text-capitalize ps-3">Label</h6>
            </div>
          </div>
          <div class="card-body px-0 pb-2">
            <div class="table-responsive p-0">
              <table class="table align-items-center mb-0 table-flush display" id="datatable-label">
                <thead>
                  <tr>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7">No</th>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-2">Label</th>
                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-2">Jenis</th>
                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">Hapus</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                    $no=1;
                    ?>
                    <?php $__currentLoopData = $label; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                        <div class="d-flex px-2 py-1">
                            <?php echo e($no++); ?>

                        </div>
                    </td>
                    <td>
                        <div class="d-flex px-2 py-1 text-capitalize">
                         <?php echo e($item->nama); ?>

                        </div>
                    </td>
                    <td>
                      <div class="text-capitalize">
                        <p class="text-xs font-weight-bold mb-0"><?php echo e($item->jenis->nama); ?></p>
                        <p class="text-xs text-secondary mb-0"><?php echo e($item->jenis->kategori->nama); ?></p>
                       
                      </div>
                  </td>
                      <td class="align-middle   ">
                        <div class="text-center">
                          <a href="" data-bs-toggle="modal" data-bs-target="#editDatalabel<?php echo e($item->id); ?>" style="margin: 10px;"><i class="fa-solid fa-edit"></i></a>
                        <a href="<?php echo e(route('label_delete', ['id'=>$item->id])); ?>" onclick="if (confirm('Delete selected item?')){return true;}else{event.stopPropagation(); event.preventDefault();};" style="margin: 10px;"><i class="fa-solid fa-trash"></i></a>
                        </div>
                      </td>
                  </tr>
                  <!-- Modal edit kategori -->
                  <div class="modal fade" id="editDatalabel<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                      <div class="modal-content">
                        <form method="post" action="<?php echo e(route('label_update')); ?>">
                          <?php echo csrf_field(); ?>
                        <div class="modal-header">
                          <h5 class="modal-title font-weight-normal" id="tambahDataLabel">Edit Label</h5>
                          <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                                <div class="row">
                                  <div class="col-md-12">        
                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">         
                                    <div class="form-group my-3">
                                      <label class="form-label">Nama</label>
                                      <input name="nama" type="text" class="form-control" value="<?php echo e($item->nama); ?>" required>
                                    </div>
                                  </div>
                                  <div class="col-md-12">
                                    <div class="input-group input-group-static mb-4">
                                      <label for="exampleFormControlSelect1" class="ms-0">Jenis</label>
                                      <select name="jenis_id" class="form-control text-capitalize" id="exampleFormControlSelect1">
                                        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($jen->id == $item->jenis_id): ?>
                                            <?php
                                                $select = "selected";
                                            ?>
                                        <?php else: ?>
                                          <?php
                                            $select = "";
                                          ?>
                                        <?php endif; ?>
                                        <option class="text-capitalize" <?php echo e($select); ?> value="<?php echo e($jen->id); ?>"><?php echo e($jen->kategori->nama." - ".$jen->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                      </select>
                                    </div>
                                  </div>
                                  <div class="col-md-12">
                                    <div class="form-group">
                                      <label class="form-label">Keterangan</label>
                                      <textarea  name="keterangan" class="form-control" rows="5" placeholder="keterangan" spellcheck="false" ><?php echo e($item->keterangan); ?></textarea>
                                    </div>
                                  </div>
                                </div> 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
                          <button type="submit" class="btn bg-gradient-primary">Update Jenis</button>
                        </div>
                      </form>
                      </div>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

  
  <!-- Modal tambah kategori -->
  <div class="modal fade" id="tambahDataKategori" tabindex="-1" role="dialog" aria-labelledby="tambahDataKategori" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <form method="post" action="<?php echo e(route('kategori_simpan')); ?>">
          <?php echo csrf_field(); ?>
        <div class="modal-header">
          <h5 class="modal-title font-weight-normal" id="tambahDataKategori">Tambah Kategori</h5>
          <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="input-group input-group-outline my-3">
                      <label class="form-label">Nama</label>
                      <input name="nama" type="text" class="form-control" required>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="input-group input-group-dynamic">
                      <textarea  name="keterangan" class="form-control" rows="5" placeholder="keterangan" spellcheck="false" ></textarea>
                    </div>
                  </div>
                </div> 
        </div>
      
        <div class="modal-footer">
          <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn bg-gradient-primary">Simpan Kategori</button>
        </div>
      </form>
      </div>
    </div>
  </div>
  <!-- Modal tambah jenis -->
  <div class="modal fade" id="tambahDataJenis" tabindex="-1" role="dialog" aria-labelledby="tambahDataJenis" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <form method="post" action="<?php echo e(route('jenis_simpan')); ?>">
          <?php echo csrf_field(); ?>
        <div class="modal-header">
          <h5 class="modal-title font-weight-normal" id="tambahDataLabel">Tambah Jenis</h5>
          <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="input-group input-group-outline my-3">
                      <label class="form-label">Nama</label>
                      <input name="nama" type="text" class="form-control" required>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="input-group input-group-static mb-4">
                      <label for="exampleFormControlSelect1" class="ms-0">Kategori</label>
                      <select name="kategori_id" class="form-control" id="exampleFormControlSelect1">
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kat->id); ?>"><?php echo e($kat->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="input-group input-group-dynamic">
                      <textarea  name="keterangan" class="form-control" rows="5" placeholder="keterangan" spellcheck="false" ></textarea>
                    </div>
                  </div>
                </div> 
        </div>
      
        <div class="modal-footer">
          <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn bg-gradient-primary">Simpan Kategori</button>
        </div>
      </form>
      </div>
    </div>
  </div>
  <!-- Modal tambah label -->
  <div class="modal fade" id="tambahDataLabel1" tabindex="-1" role="dialog" aria-labelledby="tambahDataLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <form method="post" action="<?php echo e(route('label_simpan')); ?>">
          <?php echo csrf_field(); ?>
        <div class="modal-header">
          <h5 class="modal-title font-weight-normal" id="tambahDataLabel">Tambah Label</h5>
          <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="input-group input-group-outline my-3">
                      <label class="form-label">Nama</label>
                      <input name="nama" type="text" class="form-control" required>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="input-group input-group-static mb-4">
                      <label for="exampleFormControlSelect1" class="ms-0">Jenis</label>
                      <select name="jenis_id" class="form-control text-capitalize" id="exampleFormControlSelect1" >
                        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option class="text-capitalize" value="<?php echo e($jen->id); ?>"><?php echo e($jen->kategori->nama." - ".$jen->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="input-group input-group-dynamic">
                      <textarea  name="keterangan" class="form-control" rows="5" placeholder="keterangan" spellcheck="false" ></textarea>
                    </div>
                  </div>
                </div> 
        </div>
      
        <div class="modal-footer">
          <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn bg-gradient-primary">Simpan Label</button>
        </div>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AMD\Documents\project\jrmedia\resources\views/alat/alat.blade.php ENDPATH**/ ?>