<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KategoriModelController extends Controller
{
    //
}
